package com.apan.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.apan.json.AbstractJsonObject;
import com.apan.json.JackJsonUtils;
import com.apan.json.ListObject;
import com.apan.json.ResponseUtils;
import com.apan.json.StatusCode;
import com.apan.model.Students;
import com.apan.service.StudentService;
import com.apan.service.impl.StudentServiceImpl;


@Controller
@RequestMapping("student")
public class StudentServlet {
	
	public StudentService studentServiceImpl = new StudentServiceImpl();
 
 
//	http://localhost:8080/SpringMVCModel/student/getAllStudent
	@RequestMapping("/getAllStudent")
	public void getAllStudent(HttpServletRequest request, HttpServletResponse response) {
		List<Students> list = studentServiceImpl.getAllStudent();
		
		
		ListObject listObject = new ListObject();
		listObject.setItems(list);
		listObject.setCode(StatusCode.CODE_SUCCESS);
		listObject.setMsg("访问成功");
		
		
		ResponseUtils.renderJson(response, JackJsonUtils.toJson(listObject));
	}
	
	//http://localhost:8080/SpringMVCModel/student/getStudentById?key=id&value=1
	@RequestMapping("/getStudentById")
	public void getStudentById(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("key");
		String values = request.getParameter("value");
		System.out.println("key: " + key + " | value: " + values);
		List<Students> list = studentServiceImpl.getStudentById(key, values);
		
		ListObject listObject = new ListObject();
		listObject.setItems(list);
		listObject.setCode(StatusCode.CODE_SUCCESS);
		listObject.setMsg("访问成功");
		
		
		ResponseUtils.renderJson(response, JackJsonUtils.toJson(listObject));

	}
	
//	http://localhost:8080/SpringMVCModel/student/insertStudent?id=4&sname=4&age4&sex1&mobile=345
//	http://localhost:8080/SpringMVCModel/student/insertStudent?sname=4&age4&sex1&mobile=345
	@RequestMapping("/insertStudent")
	public void insertStudent(HttpServletRequest request, HttpServletResponse response, Students students) {
		
		List<Students> students2 = new ArrayList<Students>();
		students2.add(students);
		int sign = studentServiceImpl.insertStudent(students2);
		
		AbstractJsonObject obj = new AbstractJsonObject();
		obj.setCode(StatusCode.CODE_SUCCESS);
		obj.setMsg(String.valueOf(sign));;
		
		
		ResponseUtils.renderJson(response, JackJsonUtils.toJson(obj));

	}
	
//	http://localhost:8080/SpringMVCModel/student/updateStudent?key=age&value=111&id=4
	@RequestMapping("/updateStudent")
	public void updateStudent(HttpServletRequest request, HttpServletResponse response, String key, String value,int id) {
		
		int sign = studentServiceImpl.updateStudent(key, value, id);
		
		AbstractJsonObject obj = new AbstractJsonObject();
		obj.setCode(StatusCode.CODE_SUCCESS);
		obj.setMsg(String.valueOf(sign));;
		
		
		ResponseUtils.renderJson(response, JackJsonUtils.toJson(obj));
	}
	
//	http://localhost:8080/SpringMVCModel/student/deleteStudent?id=4
	@RequestMapping("/deleteStudent")
	public void deleteStudent(HttpServletRequest request, HttpServletResponse response, int id) {
		int sign = studentServiceImpl.deleteStudent(id);
		
		AbstractJsonObject obj = new AbstractJsonObject();
		obj.setCode(StatusCode.CODE_SUCCESS);
		obj.setMsg(String.valueOf(sign));;
		
		
		ResponseUtils.renderJson(response, JackJsonUtils.toJson(obj));
	}
	
	
	@RequestMapping("/test")
	public void method01(HttpServletRequest req, HttpServletResponse response) {
		String name = req.getParameter("name");
		if(name == null) {
			name = "参数错误";
		}
		
		System.out.println("name:" + name);
		ResponseUtils.render(response, name);
	}
 
}