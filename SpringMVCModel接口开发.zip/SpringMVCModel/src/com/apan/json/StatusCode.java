package com.apan.json;

public class StatusCode {
	public static final String CODE_SUCCESS = "1";

}
