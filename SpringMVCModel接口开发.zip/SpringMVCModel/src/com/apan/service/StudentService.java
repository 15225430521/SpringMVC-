package com.apan.service;

import java.util.List;

import com.apan.model.Students;

public interface StudentService {
	//获取所有学生信息
		public List<Students> getAllStudent();
		
		//根据字段查找学生信息
		public List<Students> getStudentById(String key, String values);
		
		//插入学生信息
		public int insertStudent(List<Students> students);
		
		//修改学生信息
		public int updateStudent(Students students);
		
		//修改学生信息
		public int updateStudent(String key, String value, int id);
		
		//删除学生信息
		public int deleteStudent(int id);
}