package com.apan.service.impl;

import java.util.List;

import com.apan.dao.IStudentDao;
import com.apan.dao.impl.StudentDaoImpl;
import com.apan.model.Students;
import com.apan.service.StudentService;

public class StudentServiceImpl implements StudentService{
	
	IStudentDao studentDaoImpl = new StudentDaoImpl();
 
	@Override
	public List<Students> getAllStudent() {
		// TODO Auto-generated method stub
		return studentDaoImpl.getAllStudent();
	}

	@Override
	public List<Students> getStudentById(String key, String values) {
		// TODO Auto-generated method stub
		return studentDaoImpl.getStudentById(key, values);
	}

	@Override
	public int insertStudent(List<Students> students) {
		// TODO Auto-generated method stub
		return studentDaoImpl.insertStudent(students);
	}

	@Override
	public int updateStudent(Students students) {
		// TODO Auto-generated method stub
		return studentDaoImpl.updateStudent(students);
	}

	@Override
	public int updateStudent(String key, String value, int id) {
		// TODO Auto-generated method stub
		return studentDaoImpl.updateStudent(key, value, id);
	}

	@Override
	public int deleteStudent(int id) {
		// TODO Auto-generated method stub
		return studentDaoImpl.deleteStudent(id);
	}
 
}