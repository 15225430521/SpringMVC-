package com.apan.utils;

import org.apache.commons.dbutils.QueryRunner;

public class QueryRunnerUtils {
	//创建静态QueryRunner对象
	public static QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource());

}
