package com.apan.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.mchange.v2.c3p0.ComboPooledDataSource;

public class C3P0Utils {
	
	static private ComboPooledDataSource dataSource = new ComboPooledDataSource("mysql_dev");
	
	
	
	/**
	 * 获取connection
	 * @return
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException{
		
		return dataSource.getConnection();


	}
	
	/**
	 * 获取连接池对象
	 * @return
	 */
	public static ComboPooledDataSource getDataSource(){
		return dataSource;
	}
	
	
	/**
	 * 关闭所有连接
	 * @param conn
	 * @param stmt
	 * @param rs
	 */
	public static void closeAll(Connection conn, Statement stmt, ResultSet rs){
		closeAll(conn, stmt);
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
	/**
	 * 关闭 conn stmt
	 * @param conn
	 * @param stmt
	 */
	public static void closeAll(Connection conn, Statement stmt){
		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(stmt != null){
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
