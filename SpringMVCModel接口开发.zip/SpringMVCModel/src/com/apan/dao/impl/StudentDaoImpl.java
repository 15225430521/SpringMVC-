package com.apan.dao.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.apan.dao.IStudentDao;
import com.apan.model.Students;
import com.apan.utils.QueryRunnerUtils;

public class StudentDaoImpl implements IStudentDao {
	
	QueryRunner qr = QueryRunnerUtils.qr;

	
	@Override
	public List<Students> getAllStudent() {
		// TODO Auto-generated method stub
		
		String sql = "select * from student";
		
		try {
			List<Students> Students = qr.query(sql, new BeanListHandler<Students>(Students.class));
			
			return Students;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public List<Students> getStudentById(String key, String values) {
		// TODO Auto-generated method stub
		
		String sql = "select * from student where " + key + " = ?";
		
		System.out.println(sql);
		List<Students> students = null;
		try {
			students = qr.query(sql, new BeanListHandler<Students>(Students.class), values);
			return students;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public int insertStudent(List<Students> students) {
		// TODO Auto-generated method stub
		int sign = 0;
		
//		INSERT INTO student VALUES(null, 'lisi', 28, 1, 456);
		String sql = "INSERT INTO student VALUES(null, ?, ?, ?, ?)";
		for (Students temp : students) {
			try {
				sign += qr.update(sql, temp.getSname(), temp.getAge(), temp.getSex(), temp.getMobile());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sign;
	}


	@Override
	public int updateStudent(Students students) {
		// TODO Auto-generated method stub
//		update student set sname = '1', age = 10, sex = 1, mobile = 123 where id = 3;
		int sign = 0;
		String sql = "update student set sname = ?, age = ?, sex = ?, mobile = ? where id = ?";
		try {
			sign = qr.update(sql, students.getSname(), students.getAge(), students.getSex(), students.getMobile(), students.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sign;
	}
	
	@Override
	public int updateStudent(String key, String value, int id) {
		// TODO Auto-generated method stub
		int sign = 0;
//		update student set sname = '2' where id = 3;

		String sql = "update student set " + key + " = ? where id = ?";
		try {
			sign = qr.update(sql, value, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sign;
	}


	@Override
	public int deleteStudent(int id) {
		// TODO Auto-generated method stub
		int sign = 0;
//		delete from student where id = 3;
		String sql = "delete from student where id = ?";
		try {
			sign = qr.update(sql, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sign;
	}


	
	

}
