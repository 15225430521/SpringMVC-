package com.apan.dao;

public interface MyDao {

}
